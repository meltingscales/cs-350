// CS 350, Fall 2016
//
// ptr_arith2.c: More pointer arithmetic
//
#include <stdio.h>

int main(void) {
	int b[5] = {0,0,0,0,0};
	*b = 2;          // b[0] = 2;
	*(b+3) = (*b)*2; // b[3] = b[0]*2
	printf("b[0] = %d, b[3] = %d\n", b[0], b[3]);

	// gcc -Wall will detect (e.g.) b[5] as illegal
	// but not b[i] where i == 5; accessing b[5] or
	// b[6] may cause a runtime error.
	//
	/*
	int i = 5;
	*(b+i) = 17;     // b[5] = 17 (semantic error)
	*(b+6) = 18;     // b[6] = 18 (semantic error)
	b[5] = 17;
	printf("b[%d] = %d, b[6] = %d\n", i, b[i], b[6]);
	 */

	int *p;
	p = b+2;         // p = &b[2];
	p[0] = p[1];     // *p = *(p+1) (sets b[2] = b[3])
	printf("p pts to b[%ld], b[2] = %d\n", p-b, b[2]);
	p++;             // p = p+1 (makes p point to b[3])
	printf("p pts to b[%ld]\n", p-b);
	p = &p[1];       // p++ 
	printf("p pts to b[%ld]\n", p-b);
	p[0]--;          // (*p)--
	printf("b[4] = %d\n", b[4]);
}

/* Output
b[0] = 2, b[3] = 4
p pts to b[2], b[2] = 4
p pts to b[3]
p pts to b[4]
b[4] = -1
*/